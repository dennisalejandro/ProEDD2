package proedd2;

import java.io.Serializable;
import java.util.ArrayList;

public class Campos implements Serializable {

    ArrayList<String> contenidos = new ArrayList();
    String nombree;
    String contenidoo;

    public Campos() {
    }

    public Campos(String nom, String cont) {
        this.nombree = nom;
        this.contenidoo = cont;
    }

    public ArrayList<String> getContenidos() {
        return contenidos;
    }

    public void setContenidos(ArrayList<String> cont) {
        this.contenidos = cont;
    }

    public String getContenidoA(int nA) {
        return contenidos.get(nA);
    }

    public void setContenidoA(String contA) {
        contenidos.add(contA);
    }

    public Campos(String nomb) {
        this.nombree = nomb;
    }

    public String getNombre() {
        return nombree;
    }

    public void setNombre(String nomb) {
        this.nombree = nomb;
    }

    public String getContenido() {
        return contenidoo;
    }

    public void setContenido(String cont) {
        this.contenidoo = cont;
    }

    @Override
    public String toString() {
        return "Dato: " + nombree;
    }

    public String toString2() {
        return "\nDato: " + nombree;
    }

    public int getTamano() {
        return getNombre().length() * 2 + 1;
    }
}
