package proedd2;

import java.awt.Desktop;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;

public class ExportarExcel {

    String nombreee;
    ArrayList<Campos> camp = new ArrayList();
    ArrayList<Registros> regist = new ArrayList();

    public ExportarExcel() {

    }

    public String getNombre() {
        return nombreee;
    }

    public void setNombre(String n) {
        this.nombreee = n;
    }

    public ArrayList<Campos> getCampos() {
        return camp;
    }

    public void setCampos(ArrayList<Campos> c) {
        this.camp = c;
    }

    public ArrayList<Registros> getRegistros() {
        return regist;
    }

    public void setRegistros(ArrayList<Registros> reg) {
        this.regist = reg;
    }

    public void ExportXcel() throws IOException {
        String ruta = System.getProperty("user.home") + "/" + nombreee + ".xls";
        File archivoXLS = new File(ruta);

        if (archivoXLS.exists()) {
            archivoXLS.delete();
        }
        archivoXLS.createNewFile();

        Workbook libro = new HSSFWorkbook();
        FileOutputStream archivo = new FileOutputStream(archivoXLS);

        //Utilizamos la clase Sheet para crear una nueva hoja de trabajo dentro del libro
        Sheet hoja = libro.createSheet(nombreee);
        Row fila1 = hoja.createRow(0);
        
        for (int j = 0; j < camp.size(); j++) {
            Cell celda = fila1.createCell(j);
            celda.setCellValue(camp.get(j).getNombre());
        }// fin for

        for (int i = 0; i < regist.size(); i++) {
            Row fila2 = hoja.createRow(i + 1);
            for (int j = 0; j < camp.size(); j++) {
                Cell celda = fila2.createCell(j);
                //Si no es la primera fila establecemos un valor
                celda.setCellValue(regist.get(i).getCampo().get(j).getContenido());
            }// fin for
        }// fin for

        libro.write(archivo);
        archivo.close();
        Desktop.getDesktop().open(archivoXLS);
    }// fin ExportXcel
}
