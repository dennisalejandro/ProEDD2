package proedd2;

import java.io.File;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.util.ArrayList;

public class AccesoCampo {

    private static RandomAccessFile flujo;
    private static int num_registro;
    static int tam_registro = 80;
    int tam_campo;
    int tamano_registro;
    ArrayList<String> nomb_campos = new ArrayList();

    public void crear_archivo(File archi) throws IOException {
        if (archi.exists() && !archi.isFile()) {
            throw new IOException(archi.getName() + " no es un archivo");
        }
        flujo = new RandomAccessFile(archi, "rw");
        num_registro = (int) Math.ceil((double) flujo.length() / (double) tam_registro);
    }

    public void close() throws IOException {
        flujo.close();
    }

    public static boolean setCampo(int i, Campos campo) throws IOException {
        if (i >= 0 && i <= getNum_registro()) {
            if (campo.getTamano() > tam_registro) {
                System.out.println("\nTamaño excedido");
            } else {
                flujo.seek(i * tam_registro);
                flujo.writeUTF(campo.getNombre());
                return true;
            }
        } else {
            System.out.println("\nNúmero fuera de límites");
        }
        return false;
    }

    public static int getNum_registro() {
        return num_registro;
    }

    public static void setNum_registro(int num_registro) {
        AccesoCampo.num_registro = num_registro;
    }

    public void write_Metadata(String metadata) throws IOException {
        flujo.seek(0);
        flujo.writeUTF(metadata);
        num_registro++;
    }

    public void write_Campos(ArrayList<Campos> camp, String metadata) throws IOException {
        flujo.seek(num_registro * tam_registro);
        int numCampos = camp.size();
        String temp = "" + numCampos;
        flujo.writeUTF(temp);
        num_registro++;
        for (int i = 0; i < camp.size(); i++) {
            add_Campo(camp.get(i));
        }//fin for
    }

    public static void add_Campo(Campos camp) throws IOException {
        if (setCampo(num_registro, camp)) {
            num_registro++;
        }
    }

    public void write_Registro(ArrayList<Registros> registro) throws IOException {
        for (int i = 0; i < registro.size(); i++) {
            for (int j = 0; j < registro.get(i).getCampo().size(); j++) {
                if (setCampoRegistro(num_registro, registro.get(i).getCampo().get(j))) {
                    num_registro++;
                }
            }
        }
    }

    public String read_Metadata() throws IOException {
        flujo.seek(0);
        num_registro++;
        return flujo.readUTF();
    }

    public int read_numRegistros() throws IOException {
        int n;
        flujo.seek(1 * tam_registro);
        String temp = flujo.readUTF();
        n = Integer.parseInt(temp);
        num_registro++;
        tamano_registro = n;
        return n;
    }

    public void write_numRegistros(ArrayList<Registros> registros) throws IOException {
        flujo.seek(num_registro * tam_registro);
        int numRegist = registros.size();
        String tempo = "" + numRegist;
        flujo.writeUTF(tempo);
        num_registro++;
    }

    public int read_NumCampos() throws IOException {
        String tempo;
        flujo.seek(2 * tam_registro);
        tempo = flujo.readUTF();
        int turn = Integer.parseInt(tempo);
        num_registro++;
        tam_campo = turn;
        return turn;
    }

    public ArrayList<Campos> read_Camposs() throws IOException {
        ArrayList<Campos> tempo = new ArrayList();
        for (int i = 3; i < tam_campo + 3; i++) {
            Campos campo = new Campos();
            campo = getCampo(i);
            tempo.add(campo);
            num_registro++;
            nomb_campos.add(campo.getNombre());
        }
        return tempo;
    }

    public ArrayList<Registros> read_Registrosss() throws IOException {
        ArrayList<Registros> tempo = new ArrayList();
        ArrayList<Campos> Camp_nada = new ArrayList();
        Registros registt = new Registros();
        registt.setCampo(Camp_nada);
        int acumula = 0;
        for (int i = 0; i < tamano_registro; i++) {
            registt = new Registros();
            Camp_nada = new ArrayList();
            registt.setCampo(Camp_nada);
            for (int j = 0; j < tam_campo; j++) {
                registt.getCampo().add(getCampoReg(acumula + tam_campo + 3));
                registt.getCampo().get(j).setNombre(nomb_campos.get(j));
                acumula++;
            }
            tempo.add(registt);
        }
        return tempo;
    }

    public Registros devolverRegistro(int x) throws IOException {
        Registros registro = null;
        ArrayList<Campos> nada = new ArrayList();
        if (tam_campo == 0) {
            System.out.println("Cargue");
        } else {
            int posicion = tam_campo + 3 + x;
            for (int i = 0; i < tam_campo; i++) {
                flujo.seek(posicion);
                Campos campo = new Campos();
                campo.setContenido(flujo.readUTF());
                campo.setNombre(nomb_campos.get(i));
                registro.getCampo().add(campo);
                posicion++;
            }
        }
        return registro;
    }

    public void modificarRegistro(int x, Registros tempo) throws IOException {
        if (tam_campo == 0) {
            System.out.println("Cargue");
        } else {
            int position = (x) * tam_registro;
            flujo.seek(position);
            for (int i = 0; i < tam_campo; i++) {
                for (int j = 0; j < tam_registro; j++) {
                    flujo.seek(position + j);
                    flujo.writeUTF("");
                }
                setCampoRegistro(position, tempo.getCampo().get(i));
                position++;
            }
        }
    }

    public void modificarCampo(int x, String tempo) throws IOException {
        if (tam_campo == 0) {
            System.out.println("Cargue");
        } else {
            int posicion = (x) * tam_registro;
            for (int j = 0; j < tam_registro; j++) {
                flujo.seek(posicion + j);
                flujo.writeUTF("");
            }
            flujo.seek(posicion);
            flujo.writeUTF(tempo);
        }
    }

    public ArrayList<Registros> devolverRegistros(int x, int y) throws IOException {
        ArrayList<Registros> tempo = new ArrayList();
        Registros registt = null;
        registt.setCampo(new ArrayList());
        int numm = y - x;
        x = x * tam_campo;
        y = y * tam_campo;
        int acumula = 0;
        for (int i = 0; i < numm; i++) {
            registt = new Registros();
            for (int j = 0; j < tam_campo; j++) {
                registt.getCampo().get(j).setNombre(nomb_campos.get(j));
                registt.getCampo().add(getCampo(tam_campo + 3 + (acumula * x)));
                acumula++;
                tempo.add(registt);
            }
        }
        return tempo;
    }

    public Campos getCampo(int i) throws IOException {
        if (i >= 0 && i <= getNum_registro()) {
            flujo.seek(i * tam_registro);
            return new Campos(flujo.readUTF(), null);
        } else {
            System.out.println("\nFuera de limites");
            return null;
        }
    }

    public Campos getCampoReg(int i) throws IOException {
        if (i >= 0 && i <= getNum_registro()) {
            flujo.seek(i * tam_registro);
            return new Campos(null, flujo.readUTF());
        } else {
            System.out.println("\nFuera de limites");
            return null;
        }
    }

    public boolean setCampoRegistro(int i, Campos campp) throws IOException {
        if (i >= 0 && i <= getNum_registro()) {
            if (campp.getTamano() > tam_registro) {
                System.out.println("\nExcedido");
            } else {
                flujo.seek(i * tam_registro);
                flujo.writeUTF(campp.getContenido());
                return true;
            }
        } else {
            System.out.println("\nFuera de límites");
        }
        return false;
    }

    public void guardarIndices(ArrayList<Integer> indexx) throws IOException {
        int space = 20;
        flujo.seek(0);
        flujo.writeUTF("" + indexx.size());
        for (int i = 1; i < indexx.size() + 1; i++) {
            flujo.seek(i * space);
            flujo.writeUTF(indexx.get(i) + "");
        }
    }

    public ArrayList<Integer> carga_Index() throws IOException {
        int space = 20;
        ArrayList<Integer> tempo = new ArrayList();
        flujo.seek(0);
        int cantIndex = Integer.parseInt(flujo.readUTF());
        for (int i = 1; i < cantIndex + 1; i++) {
            flujo.seek(i * space);
            int j = Integer.parseInt(flujo.readUTF());
            tempo.add(j);
        }
        return tempo;
    }

}
