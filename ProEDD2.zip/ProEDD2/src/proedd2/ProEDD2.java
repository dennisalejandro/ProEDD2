/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proedd2;

import de.javasoft.plaf.synthetica.SyntheticaBlackEyeLookAndFeel;
import java.text.ParseException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;


public class ProEDD2 {

    public static void main(String[] args) throws UnsupportedLookAndFeelException {
        
        try {
            UIManager.setLookAndFeel(new SyntheticaBlackEyeLookAndFeel());
            GUI inicio = new GUI();
            inicio.setLocationRelativeTo(null);
            inicio.setVisible(true);
        } catch (ParseException ex) {
            Logger.getLogger(ProEDD2.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        
    }
    
}
