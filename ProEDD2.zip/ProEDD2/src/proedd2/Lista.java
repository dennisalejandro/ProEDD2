package proedd2;

import java.util.*;

public class Lista {

    public static ArrayList<Integer> ingresado;

    public Lista() {
        ingresado = new ArrayList<Integer>();
    }

    public boolean busca(int valor) {
        boolean encuentra = false;
        for (int i = 0; i < ingresado.size() && !encuentra; i++) {
            if (ingresado.get(i) == valor) {
                encuentra = true;
            }
        }//fin for
        return encuentra;
    }
}
