package proedd2;

public class Nodo{
    
    public int []size;
    public Nodo []nodo;
    public boolean tengoChildren = false;
    public static int numValor;
    public int ocupados = 0;
    public Nodo padre;
    
    public Nodo(){
       nodo = new Nodo [Raiz.grade * 2 + 3];
       size = new int [Raiz.grade * 2 + 1];
    }
    
}
