package proedd2;

import java.util.*;

public class Raiz {

    public static boolean esRaiz;
    public static int levell = 1;
    public static int print = 1;
    public static int grade;
    public static String arbol = "";
    public Nodo first_node;

    public Raiz(int grado) {
        this.grade = grado / 2;
        first_node = new Nodo();
        Lista llevaIngresos = new Lista();
        esRaiz = true;
    }

    public void insert(int value) {
        if (first_node.tengoChildren == false) {
            int j = 0;
            for (int i = 0; i < first_node.size.length; i++) {
                if (first_node.size[i] == 0) {
                    first_node.size[i] = value;
                    Lista.ingresado.add(value);
                    j = i;
                    ordenar(first_node.size, 6);
                    break;
                }
            }
            if (j == 2 * grade) {
                split(first_node);
            }
        } else {
            setTengoHijos(first_node);
            ingresarEnHijos(first_node, value);
        }
    }//fin insertar

// ordenar raiz
    public void ordenar(int arr[], int longitud) {
        longitud = 0;
        for (int i = 0; i < arr.length; i++) {
            if (arr[i] != 0) {
                longitud++;
            } else {
                break;
            }
        }
        for (int a = 0; a < longitud; a++) {
            for (int b = 0; b < longitud - 1; b++) {
                if (arr[b] > arr[b + 1]) {
                    int temp = arr[b];
                    arr[b] = arr[b + 1];
                    arr[b + 1] = temp;
                }
            }
        }
    }//fin ordenar

    public void setTengoHijos(Nodo node) {
        if (node == first_node) {
            if (first_node.nodo[0] != null) {
                first_node.tengoChildren = true;
            }
        }
        for (int i = 0; i < node.nodo.length; i++) {
            if (node.nodo[i] != null) {
                node.tengoChildren = true;
                setTengoHijos(node.nodo[i]);
            }
        }
    }//fin set

    public void ingresarEnHijos(Nodo hijos, int value) {
        boolean entro = false;
        if (hijos != null && !hijos.tengoChildren) {
            ColocaValueEnArreglo(hijos, value);
            entro = true;
        }
        for (int i = 0; hijos != null && i < 2 * grade + 1 && !entro; i++) {
            if (value < hijos.size[i] || hijos.size[i] == 0) {
                entro = true;
                ingresarEnHijos(hijos.nodo[i], value);
                i = 2 * grade;
            }
        }
    }//fin ingresar hijos

    public void ColocaValueEnArreglo(Nodo node, int value) {
        int conta = 0;
        while (conta <= 2 * grade) {
            if (node.size[conta] == 0) {
                node.size[conta] = value;
                ordenar(node.size, 5);
                Lista.ingresado.add(value);

                if (conta == 2 * grade) {
                    split(node);
                }
                break;
            }
            conta++;
        }
    }//fin coloca valor en arreglo

    public void ordenarNodos(Nodo ordena) {
        int i = 0, j;
        Nodo temp;
        while (i < 2 * grade + 3 && ordena.nodo[i] != null) {
            j = 0;
            while (j < 2 * grade + 2 && ordena.nodo[j] != null && ordena.nodo[j + 1] != null) {
                if (ordena.nodo[j].size[0] > ordena.nodo[j + 1].size[0]) {
                    temp = ordena.nodo[j];
                    ordena.nodo[j] = ordena.nodo[j + 1];
                    ordena.nodo[j + 1] = temp;
                }
                j++;
            }
            i++;
        }
    }//fin ordenar nodos

    public void split(Nodo newNode) {
        Nodo hijoIzq = new Nodo();
        Nodo hijoDer = new Nodo();
        //split general 
        if (newNode.nodo[0] != null) { //si tiene hijos antes de hacer el split entonces
            for (int i = 0; i < grade + 1; i++) { // los separa los hijos del nodo en hijoIzq e hijoDer
                hijoIzq.nodo[i] = newNode.nodo[i];
                hijoIzq.nodo[i].padre = hijoIzq;
                newNode.nodo[i] = null;
                hijoDer.nodo[i] = newNode.nodo[grade + 1 + i];
                hijoDer.nodo[i].padre = hijoDer;
                newNode.nodo[grade + 1 + i] = null;
            }
        }//fin if newNode
        for (int i = 0; i < grade; i++) { //valores en hijoIzq e hijoDer
            hijoIzq.size[i] = newNode.size[i];
            newNode.size[i] = 0;
            hijoDer.size[i] = newNode.size[grade + 1 + i];
            newNode.size[grade + 1 + i] = 0;
        }
        newNode.size[0] = newNode.size[grade];
        newNode.size[grade] = 0; //queda en el nodo, solo el valor que subio

        newNode.nodo[0] = hijoIzq; //asigna al nodo el nuevo hijoIzq
        newNode.nodo[0].padre = newNode;
        newNode.nodo[1] = hijoDer; // asigna al nodo el nuevo hijoDer
        newNode.nodo[1].padre = newNode;
        setTengoHijos(first_node);
        ordenarNodos(newNode);

        // luego del split y asignar los hijos Izq,Der
        if (newNode.padre != null) { // subir el valor al padre
            boolean subirr = false;
            for (int i = 0; i < newNode.padre.size.length && subirr == false; i++) {
                if (newNode.padre.size[i] == 0) {
                    newNode.padre.size[i] = newNode.size[0];
                    subirr = true;
                    newNode.size[0] = 0;
                    ordenar(newNode.padre.size, 5);
                }
            }
            int hijosPos = 0;
            for (int i = 0; i < 2 * grade + 3; i++) {
                if (newNode.padre.nodo[i] != null) {
                    hijosPos++;
                } else {
                    break;
                }
            }//fin for
            newNode.padre.nodo[hijosPos] = newNode.nodo[0];
            newNode.padre.nodo[hijosPos + 1] = newNode.nodo[1];
            newNode.padre.nodo[hijosPos].padre = newNode.padre;
            newNode.padre.nodo[hijosPos + 1].padre = newNode.padre;
            int aqui = 0;
            for (int i = 0; i < 2 * grade + 3 && newNode.padre.nodo[i] != null; i++) {
                if (newNode.padre.nodo[i].size[0] == newNode.size[0]) {
                    aqui = i;
                    break;
                }
            }//fin for
            Nodo fatherr = newNode.padre;
            newNode = null;
            int j = aqui;
            while (j < 2 * grade + 2 && fatherr.nodo[j] != null && fatherr.nodo[j + 1] != null) {
                fatherr.nodo[j] = fatherr.nodo[j + 1];
                j++;
            }
            fatherr.nodo[j] = null;
            ordenar(fatherr.size, 5);
            ordenarNodos(fatherr);
            if (fatherr.size[2 * grade] != 0) {
                split(fatherr);
            }
        }
    }//FIN SPLIT

    //elimina de la lista el valor y vuelve a crear el arbol
    public void eliminar(int value) {
        boolean encontrado = false;
        int z = 0;
        for (int i = 0; i < Lista.ingresado.size() && !encontrado; i++) {
            if (Lista.ingresado.get(i) == value) {
                encontrado = true;
                z = i;
            }
        }//fin for
        if (encontrado == true) {
            Lista.ingresado.remove(z);
        } else {
            System.out.println("El valor a eliminar, no se encuentra en el árbol");
        }
        ArrayList<Integer> auxi = Lista.ingresado;
        Lista.ingresado = new ArrayList<Integer>();
        first_node = new Nodo();
        first_node.tengoChildren = false;
        for (int a = 0; a < auxi.size(); a++) {
            Integer y = auxi.get(a);
            int o = y.intValue();
            insert(o);
        }//fin for
    }//fin eliminar

    // buscar dato para modificar registros
    public boolean buscar(int value, Nodo node) {
        Nodo actual = node;
        boolean esta = false;
        for (int i = 0; i < Lista.ingresado.size() && !esta; i++) {
            if (Lista.ingresado.get(i) == value) {
                esta = true;
                System.out.println("El valor buscado, si se encuentra en el árbol");
                return esta;
            }//fin if
        }//fin for
        System.out.println("El valor buscado, no se encuentra en el arbol");

        if (buscarEnNodo(value, actual)) {
            System.out.println(actual.size[0]);
            esta = true;
            return esta;
        } else {
            if (!actual.tengoChildren) {
                return false;
            } else {
                if (value < actual.size[0]) {
                    System.out.println("hola");
                    actual = actual.nodo[0];
                    esta = buscar(value, actual);
                }
                int x = ultimo_valor(actual);
                for (int i = 0; i < actual.size.length; i++) {
                    if (i < actual.size.length - 1) {
                        if (actual.size[i] > 0 && actual.size[i + 1] > 0) {
                            if (value > actual.size[i] && value < actual.size[i + 1]) {
                                actual = actual.nodo[i];
                                esta = buscar(value, actual);
                            }
                        }
                        if (actual.size[i] > 0 && actual.size[i + 1] == 0) {
                            actual = actual.nodo[i + 1];
                            esta = buscar(value, actual);
                        }
                    }
                }//fin for
            }
        }
        return esta;
    }//fin buscar

    public int ultimo_valor(Nodo node) {
        int conta = 0;
        for (int i = 0; i < node.size.length; i++) {
            if (node.size[i] > 0) {
                conta++;
            }
        }
        return conta;
    }

    public boolean buscarEnNodo(int value, Nodo node) {
        boolean estaa = false;
        for (int i = 0; i < node.size.length; i++) {
            if (node.size[i] == value) {
                estaa = true;
                break;
            }
        }
        return estaa;
    }

    public String recorrer(Nodo node) {
        arbol += "\n";
        for (int i = 0; i < 2 * grade + 1; i++) {
            if (node.nodo[i] != null) {
                if (i == 0) {
                    levell++;
                    print = 1;
                } else {
                    print++;
                }
                recorrer(node.nodo[i]);
            }
            arbol += "[ ";
            for (int j = 0; node.nodo[i] != null && j < node.nodo[i].size.length; j++) {
                if (node.nodo[i].size[j] != 0) {
                    arbol += node.nodo[i].size[j] + ", ";
                }
            }
            arbol += " ]";
        }
        if (arbol.length() > (2 * grade + 3) * 4) {
            System.out.println(arbol);
            return arbol;
        }
        return arbol;
    }

    public String llamarRecorrer() {
        String mostrar;
        mostrar = recorrer(first_node);
        levell = 1;
        print = 1;
        return arbol;
    }

    public boolean esNumero(String a) {
        try {
            Integer.parseInt(a);
            return true;
        } catch (NumberFormatException e) {
            return false;
        }
    }

}
