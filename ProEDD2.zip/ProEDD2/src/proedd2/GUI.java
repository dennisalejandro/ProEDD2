package proedd2;

import java.awt.Color;
import java.awt.Font;
import java.awt.HeadlessException;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;

public class GUI extends javax.swing.JFrame {

    public GUI() {
        initComponents();
        
        JTableHeader th;
        th = jT_registros.getTableHeader();
        Font fuente = new Font("Verdana", Font.ITALIC, 13);
        th.setFont(fuente);
        jT_registros.getTableHeader().setForeground(Color.CYAN);

    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jD_campos = new javax.swing.JDialog();
        jTabbedPane1 = new javax.swing.JTabbedPane();
        jPanel1 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jT_campos = new javax.swing.JTable();
        jB_agregarCampo = new javax.swing.JButton();
        jB_eliminarCampo = new javax.swing.JButton();
        jB_guardarCampo = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        jB_cargarCampos = new javax.swing.JButton();
        jCB_cargarCampos = new javax.swing.JComboBox<>();
        jT_newCampo = new javax.swing.JTextField();
        jB_modificarCampo = new javax.swing.JButton();
        jD_mainNuevo = new javax.swing.JDialog();
        jB_generar10mil = new javax.swing.JButton();
        jB_campos = new javax.swing.JButton();
        jB_registroo = new javax.swing.JButton();
        jLabel9 = new javax.swing.JLabel();
        jb_cruzaArchivoo = new javax.swing.JButton();
        jB_estandariza = new javax.swing.JButton();
        jD_registros = new javax.swing.JDialog();
        jTabbedPane2 = new javax.swing.JTabbedPane();
        jPanel3 = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        jT_registros = new javax.swing.JTable();
        jB_agregarRegistro = new javax.swing.JButton();
        jB_eliminarRegistro = new javax.swing.JButton();
        jB_registro = new javax.swing.JButton();
        jPanel4 = new javax.swing.JPanel();
        jb_buscarRegistro = new javax.swing.JButton();
        jb_ModificaRegistro = new javax.swing.JButton();
        jt_modficaRegistro = new javax.swing.JTextField();
        jButton4 = new javax.swing.JButton();
        jButton6 = new javax.swing.JButton();
        jD_indices = new javax.swing.JDialog();
        jb_imprimirTree = new javax.swing.JButton();
        jb_guardarIndices = new javax.swing.JButton();
        Menu_elimina_campo = new javax.swing.JPopupMenu();
        Eliminar_Campo = new javax.swing.JMenuItem();
        Menu_elimina_registros = new javax.swing.JPopupMenu();
        eliminar_registro = new javax.swing.JMenuItem();
        jD_cruzarArchivos = new javax.swing.JDialog();
        jb_seleccionaArchi = new javax.swing.JButton();
        jCb_archivo1 = new javax.swing.JComboBox<>();
        jCb_archivo2 = new javax.swing.JComboBox<>();
        jb_cruzar = new javax.swing.JButton();
        jButton5 = new javax.swing.JButton();
        jComboBox1 = new javax.swing.JComboBox<>();
        jD_estandariza = new javax.swing.JDialog();
        jb_excel = new javax.swing.JButton();
        jb_xml = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        jMenuBar1 = new javax.swing.JMenuBar();
        jMenu1 = new javax.swing.JMenu();
        jMenuItem1 = new javax.swing.JMenuItem();
        jMenuItem4 = new javax.swing.JMenuItem();
        jMenuItem2 = new javax.swing.JMenuItem();
        jMenuItem3 = new javax.swing.JMenuItem();
        jMenuItem5 = new javax.swing.JMenuItem();

        jD_campos.setTitle("CAMPOS");

        jTabbedPane1.setFont(new java.awt.Font("Trebuchet MS", 1, 12)); // NOI18N

        jT_campos.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jT_campos.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {},
                {},
                {},
                {}
            },
            new String [] {

            }
        ));
        jT_campos.setComponentPopupMenu(Menu_elimina_campo);
        jScrollPane1.setViewportView(jT_campos);

        jB_agregarCampo.setFont(new java.awt.Font("Trebuchet MS", 1, 12)); // NOI18N
        jB_agregarCampo.setText("Agregar Campos");
        jB_agregarCampo.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jB_agregarCampoMouseClicked(evt);
            }
        });

        jB_eliminarCampo.setFont(new java.awt.Font("Trebuchet MS", 1, 12)); // NOI18N
        jB_eliminarCampo.setText("Eliminar Campos");
        jB_eliminarCampo.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jB_eliminarCampoMouseClicked(evt);
            }
        });

        jB_guardarCampo.setFont(new java.awt.Font("Trebuchet MS", 1, 12)); // NOI18N
        jB_guardarCampo.setText("Guardar");
        jB_guardarCampo.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jB_guardarCampoMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 375, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(57, 57, 57)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jB_agregarCampo, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jB_eliminarCampo, javax.swing.GroupLayout.DEFAULT_SIZE, 129, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jB_guardarCampo, javax.swing.GroupLayout.PREFERRED_SIZE, 113, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(52, 52, 52))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 181, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addComponent(jB_agregarCampo)
                        .addGap(18, 18, 18)
                        .addComponent(jB_eliminarCampo))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(37, 37, 37)
                        .addComponent(jB_guardarCampo)))
                .addContainerGap(22, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("Crear Campos", jPanel1);

        jB_cargarCampos.setFont(new java.awt.Font("Trebuchet MS", 1, 12)); // NOI18N
        jB_cargarCampos.setText("Cargar Campos");
        jB_cargarCampos.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jB_cargarCamposMouseClicked(evt);
            }
        });

        jT_newCampo.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jB_modificarCampo.setFont(new java.awt.Font("Trebuchet MS", 1, 12)); // NOI18N
        jB_modificarCampo.setText("Modificar");
        jB_modificarCampo.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jB_modificarCampoMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addGap(48, 48, 48)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jB_cargarCampos, javax.swing.GroupLayout.PREFERRED_SIZE, 124, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jT_newCampo, javax.swing.GroupLayout.PREFERRED_SIZE, 136, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 34, Short.MAX_VALUE)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jCB_cargarCampos, javax.swing.GroupLayout.PREFERRED_SIZE, 124, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jB_modificarCampo, javax.swing.GroupLayout.PREFERRED_SIZE, 115, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(53, 53, 53))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(84, 84, 84)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jB_cargarCampos)
                    .addComponent(jCB_cargarCampos, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(63, 63, 63)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jB_modificarCampo)
                    .addComponent(jT_newCampo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(103, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("Modificar Campos", jPanel2);

        javax.swing.GroupLayout jD_camposLayout = new javax.swing.GroupLayout(jD_campos.getContentPane());
        jD_campos.getContentPane().setLayout(jD_camposLayout);
        jD_camposLayout.setHorizontalGroup(
            jD_camposLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jD_camposLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jTabbedPane1)
                .addContainerGap())
        );
        jD_camposLayout.setVerticalGroup(
            jD_camposLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jD_camposLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jTabbedPane1)
                .addContainerGap())
        );

        jB_generar10mil.setFont(new java.awt.Font("Trebuchet MS", 1, 12)); // NOI18N
        jB_generar10mil.setText("Generar 10,000");
        jB_generar10mil.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jB_generar10milMouseClicked(evt);
            }
        });

        jB_campos.setFont(new java.awt.Font("Trebuchet MS", 1, 12)); // NOI18N
        jB_campos.setText("Campos");
        jB_campos.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jB_camposMouseClicked(evt);
            }
        });

        jB_registroo.setFont(new java.awt.Font("Trebuchet MS", 1, 12)); // NOI18N
        jB_registroo.setText("Registros");
        jB_registroo.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jB_registrooMouseClicked(evt);
            }
        });

        jLabel9.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        jLabel9.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel9.setText("MENU");
        jLabel9.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));

        jb_cruzaArchivoo.setFont(new java.awt.Font("Trebuchet MS", 1, 12)); // NOI18N
        jb_cruzaArchivoo.setText("Cruzar Archivos");
        jb_cruzaArchivoo.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jb_cruzaArchivooMouseClicked(evt);
            }
        });

        jB_estandariza.setFont(new java.awt.Font("Trebuchet MS", 1, 12)); // NOI18N
        jB_estandariza.setText("Estandarización");
        jB_estandariza.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jB_estandarizaMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout jD_mainNuevoLayout = new javax.swing.GroupLayout(jD_mainNuevo.getContentPane());
        jD_mainNuevo.getContentPane().setLayout(jD_mainNuevoLayout);
        jD_mainNuevoLayout.setHorizontalGroup(
            jD_mainNuevoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jD_mainNuevoLayout.createSequentialGroup()
                .addGap(137, 137, 137)
                .addGroup(jD_mainNuevoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jB_generar10mil, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jB_campos, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jB_registroo, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel9, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jb_cruzaArchivoo, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jB_estandariza, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(141, Short.MAX_VALUE))
        );
        jD_mainNuevoLayout.setVerticalGroup(
            jD_mainNuevoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jD_mainNuevoLayout.createSequentialGroup()
                .addContainerGap(34, Short.MAX_VALUE)
                .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(31, 31, 31)
                .addComponent(jB_generar10mil)
                .addGap(18, 18, 18)
                .addComponent(jB_campos)
                .addGap(18, 18, 18)
                .addComponent(jB_registroo)
                .addGap(18, 18, 18)
                .addComponent(jB_estandariza)
                .addGap(18, 18, 18)
                .addComponent(jb_cruzaArchivoo)
                .addGap(37, 37, 37))
        );

        jD_registros.setTitle("REGISTROS");

        jTabbedPane2.setFont(new java.awt.Font("Trebuchet MS", 1, 12)); // NOI18N

        jT_registros.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jT_registros.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {},
                {},
                {},
                {}
            },
            new String [] {

            }
        ));
        jT_registros.setComponentPopupMenu(Menu_elimina_registros);
        jScrollPane2.setViewportView(jT_registros);

        jB_agregarRegistro.setFont(new java.awt.Font("Trebuchet MS", 1, 12)); // NOI18N
        jB_agregarRegistro.setText("Agregar Registro");
        jB_agregarRegistro.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jB_agregarRegistroMouseClicked(evt);
            }
        });

        jB_eliminarRegistro.setFont(new java.awt.Font("Trebuchet MS", 1, 12)); // NOI18N
        jB_eliminarRegistro.setText("Eliminar Registro");
        jB_eliminarRegistro.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jB_eliminarRegistroMouseClicked(evt);
            }
        });

        jB_registro.setFont(new java.awt.Font("Trebuchet MS", 1, 12)); // NOI18N
        jB_registro.setText("Guardar");
        jB_registro.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jB_registroMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 379, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(44, 44, 44)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jB_agregarRegistro, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jB_eliminarRegistro))
                        .addGap(50, 50, 50)
                        .addComponent(jB_registro, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(jB_agregarRegistro)
                        .addGap(18, 18, 18)
                        .addComponent(jB_eliminarRegistro))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(19, 19, 19)
                        .addComponent(jB_registro)))
                .addContainerGap(23, Short.MAX_VALUE))
        );

        jTabbedPane2.addTab("Agregar Registros", jPanel3);

        jb_buscarRegistro.setFont(new java.awt.Font("Trebuchet MS", 1, 12)); // NOI18N
        jb_buscarRegistro.setText("Buscar");
        jb_buscarRegistro.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jb_buscarRegistroMouseClicked(evt);
            }
        });

        jb_ModificaRegistro.setFont(new java.awt.Font("Trebuchet MS", 1, 12)); // NOI18N
        jb_ModificaRegistro.setText("Modificar Registro");
        jb_ModificaRegistro.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jb_ModificaRegistroMouseClicked(evt);
            }
        });

        jt_modficaRegistro.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                jt_modficaRegistroFocusGained(evt);
            }
        });

        jButton4.setFont(new java.awt.Font("Trebuchet MS", 1, 12)); // NOI18N
        jButton4.setText("Indices");
        jButton4.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton4MouseClicked(evt);
            }
        });

        jButton6.setFont(new java.awt.Font("Trebuchet MS", 1, 12)); // NOI18N
        jButton6.setText("Imprimir Arbol");
        jButton6.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton6MouseClicked(evt);
            }
        });

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(124, 124, 124)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jb_ModificaRegistro, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jt_modficaRegistro)
                    .addComponent(jb_buscarRegistro, javax.swing.GroupLayout.PREFERRED_SIZE, 135, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                .addContainerGap(85, Short.MAX_VALUE)
                .addComponent(jButton4, javax.swing.GroupLayout.PREFERRED_SIZE, 99, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jButton6)
                .addGap(82, 82, 82))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(43, 43, 43)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton6)
                    .addComponent(jButton4))
                .addGap(36, 36, 36)
                .addComponent(jt_modficaRegistro, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(27, 27, 27)
                .addComponent(jb_buscarRegistro)
                .addGap(38, 38, 38)
                .addComponent(jb_ModificaRegistro)
                .addContainerGap(63, Short.MAX_VALUE))
        );

        jTabbedPane2.addTab("Modificar Registros", jPanel4);

        javax.swing.GroupLayout jD_registrosLayout = new javax.swing.GroupLayout(jD_registros.getContentPane());
        jD_registros.getContentPane().setLayout(jD_registrosLayout);
        jD_registrosLayout.setHorizontalGroup(
            jD_registrosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jD_registrosLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jTabbedPane2)
                .addContainerGap())
        );
        jD_registrosLayout.setVerticalGroup(
            jD_registrosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jD_registrosLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jTabbedPane2)
                .addContainerGap())
        );

        jD_indices.setTitle("INDICES");

        jb_imprimirTree.setFont(new java.awt.Font("Trebuchet MS", 1, 12)); // NOI18N
        jb_imprimirTree.setText("Imprimir Arbol");
        jb_imprimirTree.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jb_imprimirTreeMouseClicked(evt);
            }
        });

        jb_guardarIndices.setFont(new java.awt.Font("Trebuchet MS", 1, 12)); // NOI18N
        jb_guardarIndices.setText("Indices");
        jb_guardarIndices.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jb_guardarIndicesMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout jD_indicesLayout = new javax.swing.GroupLayout(jD_indices.getContentPane());
        jD_indices.getContentPane().setLayout(jD_indicesLayout);
        jD_indicesLayout.setHorizontalGroup(
            jD_indicesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jD_indicesLayout.createSequentialGroup()
                .addGap(141, 141, 141)
                .addGroup(jD_indicesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jb_imprimirTree, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jb_guardarIndices, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(144, Short.MAX_VALUE))
        );
        jD_indicesLayout.setVerticalGroup(
            jD_indicesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jD_indicesLayout.createSequentialGroup()
                .addGap(102, 102, 102)
                .addComponent(jb_guardarIndices)
                .addGap(18, 18, 18)
                .addComponent(jb_imprimirTree)
                .addContainerGap(134, Short.MAX_VALUE))
        );

        Eliminar_Campo.setText("Eliminar");
        Eliminar_Campo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Eliminar_CampoActionPerformed(evt);
            }
        });
        Menu_elimina_campo.add(Eliminar_Campo);

        eliminar_registro.setText("Eliminar");
        eliminar_registro.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                eliminar_registroActionPerformed(evt);
            }
        });
        Menu_elimina_registros.add(eliminar_registro);

        jD_cruzarArchivos.setTitle("CRUZAR ARCHIVOS");

        jb_seleccionaArchi.setFont(new java.awt.Font("Trebuchet MS", 1, 12)); // NOI18N
        jb_seleccionaArchi.setText("Seleccionar Archivo");
        jb_seleccionaArchi.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jb_seleccionaArchiMouseClicked(evt);
            }
        });

        jCb_archivo1.setName(""); // NOI18N

        jb_cruzar.setFont(new java.awt.Font("Trebuchet MS", 1, 12)); // NOI18N
        jb_cruzar.setText("Cruzar");
        jb_cruzar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jb_cruzarMouseClicked(evt);
            }
        });

        jButton5.setText("->");
        jButton5.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton5MouseClicked(evt);
            }
        });

        javax.swing.GroupLayout jD_cruzarArchivosLayout = new javax.swing.GroupLayout(jD_cruzarArchivos.getContentPane());
        jD_cruzarArchivos.getContentPane().setLayout(jD_cruzarArchivosLayout);
        jD_cruzarArchivosLayout.setHorizontalGroup(
            jD_cruzarArchivosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jD_cruzarArchivosLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jb_cruzar, javax.swing.GroupLayout.PREFERRED_SIZE, 82, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(164, 164, 164))
            .addGroup(jD_cruzarArchivosLayout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addGroup(jD_cruzarArchivosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jb_seleccionaArchi, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jCb_archivo1, javax.swing.GroupLayout.PREFERRED_SIZE, 145, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(jButton5)
                .addGap(18, 18, 18)
                .addComponent(jCb_archivo2, javax.swing.GroupLayout.PREFERRED_SIZE, 145, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(18, Short.MAX_VALUE))
        );
        jD_cruzarArchivosLayout.setVerticalGroup(
            jD_cruzarArchivosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jD_cruzarArchivosLayout.createSequentialGroup()
                .addGap(64, 64, 64)
                .addComponent(jb_seleccionaArchi)
                .addGap(18, 18, 18)
                .addGroup(jD_cruzarArchivosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jCb_archivo1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton5)
                    .addComponent(jCb_archivo2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(59, 59, 59)
                .addComponent(jb_cruzar, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(71, Short.MAX_VALUE))
        );

        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        jD_estandariza.setTitle("EXPORTAR");

        jb_excel.setFont(new java.awt.Font("Trebuchet MS", 1, 11)); // NOI18N
        jb_excel.setText("Exportar Archivo a Excel");
        jb_excel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jb_excelMouseClicked(evt);
            }
        });

        jb_xml.setFont(new java.awt.Font("Trebuchet MS", 1, 11)); // NOI18N
        jb_xml.setText("Exportar Archivo a XML");
        jb_xml.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jb_xmlMouseClicked(evt);
            }
        });

        jLabel2.setFont(new java.awt.Font("Lato", 1, 12)); // NOI18N
        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel2.setText("ESTANDARIZACIÓN");
        jLabel2.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jLabel2.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));

        javax.swing.GroupLayout jD_estandarizaLayout = new javax.swing.GroupLayout(jD_estandariza.getContentPane());
        jD_estandariza.getContentPane().setLayout(jD_estandarizaLayout);
        jD_estandarizaLayout.setHorizontalGroup(
            jD_estandarizaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jD_estandarizaLayout.createSequentialGroup()
                .addGap(111, 111, 111)
                .addGroup(jD_estandarizaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jb_excel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jb_xml, javax.swing.GroupLayout.PREFERRED_SIZE, 167, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(122, Short.MAX_VALUE))
        );
        jD_estandarizaLayout.setVerticalGroup(
            jD_estandarizaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jD_estandarizaLayout.createSequentialGroup()
                .addGap(41, 41, 41)
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(45, 45, 45)
                .addComponent(jb_excel)
                .addGap(46, 46, 46)
                .addComponent(jb_xml)
                .addContainerGap(95, Short.MAX_VALUE))
        );

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jMenu1.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jMenu1.setText("MENU");
        jMenu1.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N

        jMenuItem1.setText("Archivo Nuevo");
        jMenuItem1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem1ActionPerformed(evt);
            }
        });
        jMenu1.add(jMenuItem1);

        jMenuItem4.setText("Guardar Archivo");
        jMenuItem4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem4ActionPerformed(evt);
            }
        });
        jMenu1.add(jMenuItem4);

        jMenuItem2.setText("Cargar Archivo");
        jMenuItem2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem2ActionPerformed(evt);
            }
        });
        jMenu1.add(jMenuItem2);

        jMenuItem3.setText("Cerrar Archivo");
        jMenuItem3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem3ActionPerformed(evt);
            }
        });
        jMenu1.add(jMenuItem3);

        jMenuItem5.setText("SALIR");
        jMenuItem5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem5ActionPerformed(evt);
            }
        });
        jMenu1.add(jMenuItem5);

        jMenuBar1.add(jMenu1);

        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 490, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 318, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jMenuItem1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem1ActionPerformed
        // INGRESE NOMBRE
        String nombre;
        nombre = JOptionPane.showInputDialog(null, "Ingrese Nombre: ");
        metadata = nombre;
        archivo.setNom(nombre);

        jD_mainNuevo.pack();
        jD_mainNuevo.setModal(false);
        jD_mainNuevo.setLocationRelativeTo(this);
        jD_mainNuevo.setVisible(true);

    }//GEN-LAST:event_jMenuItem1ActionPerformed

    private void jB_generar10milMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jB_generar10milMouseClicked
        // GENERAR 10000
        Campos aux1 = new Campos();
        Campos aux2 = new Campos();
        Campos aux3 = new Campos();

        aux1.setNombre("Sexo");
        aux2.setNombre("Celular");
        aux3.setNombre("Fecha");

        campo10mil.add(aux1);
        campo10mil.add(aux2);
        campo10mil.add(aux3);

        for (int i = 0; i < 10000; i++) {
            Registros regist = new Registros();
            regist.setCampo(nuevoCampoo(campo10mil));
            for (int j = 0; j < campo10mil.size(); j++) {
                if (j == 0) {
                    if (i % 2 == 0) {
                        regist.getCampo().get(j).setContenido("F");
                    }else {
                        regist.getCampo().get(j).setContenido("M");
                    }
                    
                    if (i % 5 == 1) {
                        regist.getCampo().get(j).setContenido(i + "0" + j);
                    }
                    
                } else {
                    regist.getCampo().get(j).setContenido(i + "07" + "18");
                }
            } // fin for
            registro10mil.add(regist);
        }

        AccesoCampo acCamp = new AccesoCampo();
        File archivooo;
        try {
            //archivooo= new File(System.getProperty("user.home")+"/"+metadata+" - 10mil");
            archivooo = new File("C:\\Users\\usuario\\Desktop\\" + metadata + " - 10mil.txt");
            acCamp.crear_archivo(archivooo);
            acCamp.write_Metadata(metadata);
            acCamp.write_numRegistros(registro10mil);
            acCamp.write_Campos(campo10mil, metadata);
            acCamp.write_Registro(registro10mil);

            JOptionPane.showMessageDialog(null, "Se ha generado :)");
            acCamp.close();

        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error al generar " + e.getMessage());
        }
    }//GEN-LAST:event_jB_generar10milMouseClicked

    private void jB_camposMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jB_camposMouseClicked
        jD_campos.pack();
        jD_campos.setModal(true);
        jD_campos.setLocationRelativeTo(this);
        jD_campos.setVisible(true);
    }//GEN-LAST:event_jB_camposMouseClicked

    private void jMenuItem3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem3ActionPerformed
        // CERRAR ARCHIVO
        DefaultTableModel modelo22 = (DefaultTableModel) jT_campos.getModel();
        DefaultTableModel modelo11 = (DefaultTableModel) jT_registros.getModel();
        modelo22.setRowCount(0);
        modelo11.setRowCount(0);
        jT_registros = new JTable();
        jT_campos = new JTable();
        archivo = new Archivos();
        metadata = "";
        campos = new ArrayList();
        registros = new ArrayList();
        campos.clear();
        registros.clear();
        cargado = false;
    }//GEN-LAST:event_jMenuItem3ActionPerformed

    private void jB_agregarRegistroMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jB_agregarRegistroMouseClicked
        DefaultTableModel modelo = (DefaultTableModel) jT_registros.getModel();
        Object[] row = {};
        modelo.addRow(row);
        jT_registros.setModel(modelo);
    }//GEN-LAST:event_jB_agregarRegistroMouseClicked

    private void jB_eliminarRegistroMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jB_eliminarRegistroMouseClicked
        try {
            int selectedRow = jT_registros.getSelectedRow();
            jT_registros.remove(selectedRow);

            if (!registros.isEmpty()) {
                registros.remove(selectedRow);
            }
            JOptionPane.showMessageDialog(null, "Se eliminó :)");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error al eliminar " + e.getMessage());
        }

    }//GEN-LAST:event_jB_eliminarRegistroMouseClicked

    private void jB_registroMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jB_registroMouseClicked
        // GUARDAR REGISTROS
        String st;
        DefaultTableModel model = (DefaultTableModel) jT_registros.getModel();
        for (int i = 0; i < model.getRowCount(); i++) {
            Registros auxiliar = new Registros();
            auxiliar.setCampo(llenarCampos());

            for (int j = 0; j < model.getColumnCount(); j++) {
                st = (String) model.getValueAt(i, j);
                auxiliar.getCampo().get(j).setContenido(st);
            }// fin for2
            registros.add(auxiliar);
        }// fin for1

        for (int i = 0; i < registros.size(); i++) {
            arbolB.insert(registros.get(i).getIndex());
        }// fin for
        JOptionPane.showMessageDialog(null, "Se agregó :)");
    }//GEN-LAST:event_jB_registroMouseClicked

    private void jMenuItem2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem2ActionPerformed
        // CARGAR ARCHIVO EN CONSOLA
        AccesoCampo cam = new AccesoCampo();
        String path1 = "";
        String infoo = "";
        cargado = true;
        JFileChooser jfc = new JFileChooser();
        int seleccion = jfc.showOpenDialog(this);
        if (seleccion == JFileChooser.APPROVE_OPTION) {
            String ruta = jfc.getSelectedFile().getPath();
            path1 = ruta;
        }
        infoo = leer(path1);
        File file = new File(path1);
        try {
            cam.crear_archivo(file);
            metadata = cam.read_Metadata();
            cam.read_numRegistros();
            cam.read_NumCampos();
            //System.out.println(cam.tam_campo + " tamaño del acceso al campo");
            //System.out.println(cam.tamano_registro + " tamaño del acceso al registro");
            campos = cam.read_Camposs();
            registros = cam.read_Registrosss();
            System.out.println("Tamaño de los campos -> " + campos.size());
            System.out.println("Tamaño de los registros -> " + registros.size());
            
            campos = cam.read_Camposs();
            registros = cam.read_Registrosss();

            for (int i = 0; i < registros.size(); i++) {
                System.out.println("\033[34mRegistro #" + i);
                for (int j = 0; j < campos.size(); j++) {
                    System.out.println("\033[32mCampo #" + i + " :" + "\033[35m" + registros.get(i).getCampo().get(j).getContenido());
                    System.out.println("\033[35mCampo #" + i + " :" + "\033[35m" + registros.get(i).getCampo().get(j));
                }
            }
            System.out.println("\033[0m");
            String nombree = metadata;
            metadata = nombree;
            archivo.setNom(nombree);
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error al guardar " + e.getMessage());
        }

        //pasar información de las tablas
        DefaultTableModel model1 = (DefaultTableModel) jT_campos.getModel();
        String[] colum = new String[1];
        DefaultTableModel model2 = (DefaultTableModel) jT_campos.getModel();
        if (jT_campos.getColumnCount() == 0) {
            colum[0] = "NOMBRE CAMPOS";
            jT_campos.setModel(new javax.swing.table.DefaultTableModel(new Object[][]{}, colum));
            model2.addColumn(colum);
        }

        for (int i = 0; i < campos.size(); i++) {
            String aux = campos.get(i).getNombre();
            Object[] row = {aux};
            model1.addRow(row);
        }
        jT_campos.setModel(model1);

    }//GEN-LAST:event_jMenuItem2ActionPerformed

    private void jB_registrooMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jB_registrooMouseClicked
        // registros
        if (registros.size() == 0) {
            String[] columnas = new String[campos.size()];

            for (int i = 0; i < campos.size(); i++) {
                columnas[i] = campos.get(i).getNombre();
            }
            jT_registros.setModel(new javax.swing.table.DefaultTableModel(
                    new Object[][]{},
                    columnas
            ));
            DefaultTableModel modelo2 = (DefaultTableModel) jT_registros.getModel();
            jT_registros.setModel(modelo2);
        } else {
            String[] columna = new String[campos.size()];

            for (int i = 0; i < campos.size(); i++) {
                columna[i] = campos.get(i).getNombre();
            }
            jT_registros.setModel(new javax.swing.table.DefaultTableModel(
                    new Object[][]{},
                    columna
            ));
            DefaultTableModel model2 = (DefaultTableModel) jT_registros.getModel();
            jT_registros.setModel(model2);
            DefaultTableModel model3 = (DefaultTableModel) jT_registros.getModel();
            String[] row = new String[campos.size()];
            for (int i = 0; i < registros.size(); i++) {
                for (int j = 0; j < campos.size(); j++) {
                    row[j] = registros.get(i).getCampo().get(j).getContenido();
                }
                model3.addRow(row);
            }
            jT_registros.setModel(model3);
        }

        jD_registros.pack();
        jD_registros.setModal(true);
        jD_registros.setLocationRelativeTo(this);
        jD_registros.setVisible(true);
    }//GEN-LAST:event_jB_registrooMouseClicked

    private void jMenuItem4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem4ActionPerformed
        // GUARDAR ARCHIVO
        AccesoCampo acCamp = new AccesoCampo();
        File archivooo;
        try {
            for (int i = 0; i < registros.size(); i++) {
                System.out.println("\033[34mRegistro #" + i);
                for (int j = 0; j < campos.size(); j++) {
                    //registros.get(i);
                    //registros.get(i).getCampos();
                    //registros.get(i).getCampos().get(j).getContenido();
                    //System.out.println("Campo #"+i+" :"+registros.get(i).getCampos() );

                    System.out.println("\033[32mCampo #" + i + " :" + "\033[35m" + registros.get(i).getCampo().get(j).getContenido());
                }// fin for2
            }// fin for1
            System.out.println("\033[0m");
            archivooo = new File("C:\\Users\\usuario\\Desktop\\" + " - " + metadata + ".txt");
            acCamp.crear_archivo(archivooo);
            acCamp.write_Metadata(metadata);
            acCamp.write_Registro(registros);
            acCamp.write_numRegistros(registros);
            acCamp.write_Campos(campos, metadata);
            JOptionPane.showMessageDialog(null, "Se ha guardado :)");
            acCamp.close();
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(null, "Error al guardar " + ex.getMessage());
        }

    }//GEN-LAST:event_jMenuItem4ActionPerformed

    private void jMenuItem5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem5ActionPerformed
        // SALIR
        int resp = JOptionPane.showConfirmDialog(this, "¿Seguro que desea salir?");
        if (resp == 0) {
            System.exit(0);
        }
    }//GEN-LAST:event_jMenuItem5ActionPerformed

    private void Eliminar_CampoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Eliminar_CampoActionPerformed
        // ELIMINAR CAMPO
        int selectRow = jT_campos.getSelectedRow();
        jT_campos.remove(selectRow);

        try {
            if (!campos.isEmpty()) {
                campos.remove(selectRow);
            }
            JOptionPane.showMessageDialog(null, "Se eliminó :)");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error al eliminar campo " + e.getMessage());
        }
    }//GEN-LAST:event_Eliminar_CampoActionPerformed

    private void eliminar_registroActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_eliminar_registroActionPerformed
        // ELIMINAR REGISTRO
        int selectRow = jT_registros.getSelectedRow();
        jT_registros.remove(selectRow);
        try {
            if (!registros.isEmpty()) {
                registros.remove(selectRow);
            }
            JOptionPane.showMessageDialog(null, "Se eliminó :)");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error al eliminar registro " + e.getMessage());
        }
    }//GEN-LAST:event_eliminar_registroActionPerformed

    private void jb_imprimirTreeMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jb_imprimirTreeMouseClicked
        // IMPRIMIR ARBOL
        if (registros.size() != 0) {
            indicesAux.clear();
            for (int i = 0; i < registros.size(); i++) {
                indicesAux.add(i);
            }// fin for
        }//fin if
        if (indicesAux.isEmpty()) {
            JOptionPane.showMessageDialog(null, "Verifique si hay índices cargados");
        } else {
            crearArbol(indicesAux);
        }
    }//GEN-LAST:event_jb_imprimirTreeMouseClicked

    private void jb_guardarIndicesMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jb_guardarIndicesMouseClicked
        // GUARDAR INDICES
        if (registros.size() != 0) {
            indicesAux.clear();
            for (int i = 0; i < registros.size(); i++) {
                indicesAux.add(i);
            }
        }
        if (indicesAux.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Cargue registros para generar árbol");
        } else {
            crearArbol(indicesAux);

            try {
                File archivo = new File("C:\\Users\\usuario\\Desktop\\" + metadata + " - TREE.txt");
                FileWriter escribir = new FileWriter(archivo, true);
                String acumula = "";

                for (int i = 0; i < indicesAux.size(); i++) {
                    acumula += indicesAux.get(i) + "\n";
                }
                escribir.write(acumula);
                escribir.close();
            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, "Error al escribir " + e.getMessage());
            }

        }
    }//GEN-LAST:event_jb_guardarIndicesMouseClicked

    private void jb_seleccionaArchiMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jb_seleccionaArchiMouseClicked
        // SELECCIONAR ARCHIVO 1
        AccesoCampo access = new AccesoCampo();
        String pathh = "";
        String infoo = "";
        JFileChooser jfc = new JFileChooser();
        int selection = jfc.showOpenDialog(this);
        if (selection == JFileChooser.APPROVE_OPTION) {
            String ruta = jfc.getSelectedFile().getPath();
            pathh = ruta;
        }
        infoo = leer(pathh);
        File archivoo = new File(pathh);

        try {
            access.crear_archivo(archivoo);
            metadata = access.read_Metadata();
            //System.out.println("LLEGO AQUI");
            access.read_numRegistros();
            access.read_NumCampos();
            //System.out.println(access.tam_campo + " tamaño acceso campo");
            //System.out.println(access.tamano_registro + " tamaño acceso registro");
            //System.out.println("-------------------------");
            camposCruza1 = access.read_Camposs();
            registros2 = access.read_Registrosss();
            System.out.println("Tamaño al leer registro -> " + registros2.size());
            System.out.println("Tamaño al leer campo -> " + camposCruza1.size());

            camposCruza1 = access.read_Camposs();
            registros2 = access.read_Registrosss();
            
            String nombree = metadata;
            metadata = nombree;
            archivo.setNom(nombree);

        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error al cargar archivo " + e.getMessage());
        }

        DefaultComboBoxModel model = new DefaultComboBoxModel();
        for (Campos campo : camposCruza1) {
            model.addElement(campo);
        }
        jCb_archivo1.setModel(model);
        JOptionPane.showMessageDialog(null, "Se agregó al comboBox :)");
    }//GEN-LAST:event_jb_seleccionaArchiMouseClicked

    private void jb_cruzarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jb_cruzarMouseClicked
        // CRUZAR ARCHIVOS
        if (registros2.size() == registros.size()) {
            for (int i = 0; i < campos.size(); i++) {
                camposCruza2.add(campos.get(i));
            }

            for (int j = 0; j < jCb_archivo2.getItemCount(); j++) {
                camposCruza2.add(jCb_archivo2.getItemAt(j));
            }
            System.out.println("********** CAMPOS NUEVOS (CRUZADOS) **********");

            for (int i = 0; i < camposCruza2.size(); i++) {
                System.out.println(camposCruza2.get(i).getNombre());
            }
            System.out.println("-----------------------------------------------");
            int acumula1 = 0;
            int acumula2 = 0;

            for (int i = 0; i < registros.size(); i++) {
                Registros auxiliarRegistro = new Registros();
                auxiliarRegistro.setCampo(nuevoCampoo(camposCruza2));
                for (int j = 0; j < camposCruza2.size(); j++) {
                    if (j < campos.size()) {
                        auxiliarRegistro.getCampo().get(j).setContenido(registros.get(i).getCampo().get(acumula1).getContenido());
                        acumula1++;
                    } else {
                        auxiliarRegistro.getCampo().get(j).setContenido(registros2.get(i).getCampo().get(acumula2).getContenido());
                        acumula2++;
                    }
                }//fin for2
                registros3.add(auxiliarRegistro);
                acumula1 = 0;
                acumula2 = 0;
            }//fin for principal

            AccesoCampo accessCampo = new AccesoCampo();
            File archivoo;
            try {
                for (int i = 0; i < registros3.size(); i++) {
                    System.out.println("\033[34mRegistro #" + i);
                    for (int j = 0; j < camposCruza2.size(); j++) {
                        System.out.println("\033[32mCampo #" + i + " :" + "\033[35m" + registros3.get(i).getCampo().get(j).getContenido());
                    }//fin for2
                }//fin for principal
                System.out.println("\033[0m");
                archivoo = new File("C:\\Users\\usuario\\Desktop\\" + " " + metadata + "- Archivo_Cruzado.txt");
                accessCampo.crear_archivo(archivoo);
                accessCampo.write_Metadata(metadata);
                accessCampo.write_numRegistros(registros3);
                accessCampo.write_Campos(camposCruza2, metadata);
                accessCampo.write_Registro(registros3);
                JOptionPane.showMessageDialog(null, "Se ha guardado :)");
            } catch (IOException e) {
                JOptionPane.showMessageDialog(null, "Error al cruzar archivo " + e.getMessage());
            }

        }//fin if -- registros.size2() == registros.size()
    }//GEN-LAST:event_jb_cruzarMouseClicked

    private void jButton5MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton5MouseClicked
        // AGREGAR AL OTRO COMBOBOX
        Campos auxiliar = new Campos();
        auxiliar = (Campos) jCb_archivo1.getSelectedItem();
        model2_archi.addElement(auxiliar);
        jCb_archivo2.setModel(model2_archi);
    }//GEN-LAST:event_jButton5MouseClicked

    private void jb_cruzaArchivooMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jb_cruzaArchivooMouseClicked
        jD_cruzarArchivos.pack();
        //jD_cruzarArchivos.setModal(true);
        jD_cruzarArchivos.setLocationRelativeTo(this);
        jD_cruzarArchivos.setVisible(true);
    }//GEN-LAST:event_jb_cruzaArchivooMouseClicked

    private void jB_estandarizaMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jB_estandarizaMouseClicked
        jD_estandariza.pack();
        jD_estandariza.setModal(true);
        jD_estandariza.setLocationRelativeTo(this);
        jD_estandariza.setVisible(true);
    }//GEN-LAST:event_jB_estandarizaMouseClicked

    private void jb_excelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jb_excelMouseClicked
        // EXPORTAR A EXCEL
        if (campos.isEmpty() || registros.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Error al exportar excel");
        } else {
            ExportarExcel exceel = new ExportarExcel();
            exceel.setCampos(campos);
            exceel.setRegistros(registros);
            exceel.setNombre(archivo.getNom());
            JOptionPane.showMessageDialog(null, "Se ha exportado :)");
            try {
                exceel.ExportXcel();
            } catch (IOException exx) {
                JOptionPane.showMessageDialog(null, "Error al exportar excel " + exx.getMessage());
            }
        }
    }//GEN-LAST:event_jb_excelMouseClicked

    private void jb_xmlMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jb_xmlMouseClicked
        // EXPORTAR A XML
        if (campos.isEmpty() || registros.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Error al exportar XML");
        } else {
            ExportarXML exportaar = new ExportarXML();
            exportaar.setNomArchi(archivo.getNom());
            exportaar.setRegis(registros);
            JOptionPane.showMessageDialog(null, "Se ha exportado :), ¡Lo encontrará en Desktop!");
            try {
                exportaar.saveXML();
            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, "Error al exportar excel " + e.getMessage());
            }
        }
    }//GEN-LAST:event_jb_xmlMouseClicked

    private void jb_buscarRegistroMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jb_buscarRegistroMouseClicked
        // BUSCAR PARA MODIFICAR REGISTRO
        if (indicesAux.isEmpty()) {
            try {
                String texto = "";
                String path = "";
                JFileChooser jfc = new JFileChooser();
                int selection = jfc.showOpenDialog(this);
                if (selection == JFileChooser.APPROVE_OPTION) {
                    String rutt = jfc.getSelectedFile().getPath();
                    path = rutt;
                }

                FileReader fr = new FileReader(path);
                BufferedReader br = new BufferedReader(fr);
                //contenido
                while ((texto = br.readLine()) != null) {
                    indicesAux.add(Integer.parseInt(texto));
                    texto = "";
                }
                crearArbol(indicesAux);
            } //Si se causa un error al leer cae aqui
            catch (HeadlessException | IOException | NumberFormatException e) {
                JOptionPane.showMessageDialog(null, "Error al leer " + e.getMessage());
            }
        } else {
            crearArbol(indicesAux);
        }

        int modReg;
        modReg = Integer.parseInt(jt_modficaRegistro.getText());
        boolean existe;
        existe = arbolB.buscar(modReg, arbolB.first_node);

        if (existe == false) {
            JOptionPane.showMessageDialog(null, "No existe en el árbol");
            jb_ModificaRegistro.disable();
            jb_ModificaRegistro.enable(false);
        } else {
            indexGlobal = modReg;
            jb_ModificaRegistro.enable();
            jb_ModificaRegistro.enable(true);
            JOptionPane.showMessageDialog(null, "Si existe en el árbol");

        }
    }//GEN-LAST:event_jb_buscarRegistroMouseClicked

    private void jb_ModificaRegistroMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jb_ModificaRegistroMouseClicked
        // MODIFICAR REGISTRO
        try {
            String infoo = "";
            String path = "";
            int num = indexGlobal;
            JFileChooser jfc = new JFileChooser();
            int seleccion = jfc.showOpenDialog(this);
            if (seleccion == JFileChooser.APPROVE_OPTION) {
                String rutt = jfc.getSelectedFile().getPath();
                path = rutt;
            }
            infoo = leer(path);
            File archivoo = new File(path);
            AccesoCampo accessField = new AccesoCampo();
            accessField.crear_archivo(archivoo);
            int numReg = accessField.read_numRegistros();
            int numCamp = accessField.read_NumCampos();
            ArrayList<Campos> tempo = accessField.read_Camposs();
            
            if (num > numReg) {
                JOptionPane.showMessageDialog(null, "No existe esa posición");
            } else {
                for (int i = 0; i < numCamp; i++) {
                    if ((i + 3 + numCamp + num) > (numCamp + numCamp + numReg + 3)) {
                        JOptionPane.showMessageDialog(null, "ERROR!, no hay información");
                    } else {
                        String value = JOptionPane.showInputDialog("Ingrese info del campo " + tempo.get(i).getNombre() + ":");
                        accessField.modificarCampo(i + 3 + numCamp + num, value);
                        System.out.println(i + 3 + numCamp + num);
                    }
                }//fin for
            }
            accessField.close();
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error al modificar registro " + e.getMessage());
        }
    }//GEN-LAST:event_jb_ModificaRegistroMouseClicked

    private void jB_modificarCampoMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jB_modificarCampoMouseClicked
        try {
            AccesoCampo cam = new AccesoCampo();
            String campTempo = jT_newCampo.getText();
            cam.crear_archivo(archivoo_global);
            cam.read_Metadata();
            int cantRegistros = cam.read_numRegistros();
            int cantCampos = cam.read_NumCampos();
            int x = jCB_cargarCampos.getSelectedIndex();
            cam.modificarCampo(x + 3, campTempo);
            int acumula = cantCampos + x + 3;

            if (jT_newCampo.equals("")) {
                JOptionPane.showMessageDialog(this, "Error, el campo está vacio");
            } else {
                for (int i = 0; i < cantRegistros; i++) {
                    String neww = JOptionPane.showInputDialog("Ingrese el nuevo campo: " + campTempo + " del Registro#" + i + ": ");
                    cam.modificarCampo(acumula, neww);
                    acumula += cantCampos;
                }// fin for
            }

        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error al modificar " + e.getMessage());
        }
    }//GEN-LAST:event_jB_modificarCampoMouseClicked

    private void jB_cargarCamposMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jB_cargarCamposMouseClicked
        // BOTON CARGAR CAMPOS
        try {
            ArrayList<Campos> tempoCampo = new ArrayList();
            String infoo = "";
            String path = "";
            JFileChooser jfc = new JFileChooser();
            int selection = jfc.showOpenDialog(this);

            if (selection == JFileChooser.APPROVE_OPTION) {
                String rutt = jfc.getSelectedFile().getPath();
                path = rutt;
            }
            infoo = leer(path);
            File archivoo = new File(path);
            archivoo_global = archivoo;
            AccesoCampo accessCam = new AccesoCampo();
            try {
                accessCam.crear_archivo(archivoo);
            } catch (IOException e) {
                JOptionPane.showMessageDialog(null, "Error al cargar campo " + e.getMessage());
            }
            try {
                accessCam.read_numRegistros();
                accessCam.read_NumCampos();
                tempoCampo = accessCam.read_Camposs();
            } catch (IOException ex) {
                JOptionPane.showMessageDialog(null, "Error al leer número de campos y registros  " + ex.getMessage());
            }
            DefaultComboBoxModel model = new DefaultComboBoxModel();
            for (Campos t : tempoCampo) {
                model.addElement(t);
            }
            jCB_cargarCampos.setModel(model);

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error al cargar campo " + e.getMessage());
        }
    }//GEN-LAST:event_jB_cargarCamposMouseClicked

    private void jB_guardarCampoMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jB_guardarCampoMouseClicked
        try {
            /*JFileChooser file = new JFileChooser();
            file.showSaveDialog(this);
            File guarda = file.getSelectedFile();
            */
            DefaultComboBoxModel modelo1 = new DefaultComboBoxModel();
            DefaultTableModel modelo = (DefaultTableModel) jT_campos.getModel();
            Campos auxiliar = new Campos();
            int verificar = 0;
            String st;
            for (int i = 0; i < modelo.getRowCount(); i++) {
                for (int j = 0; j < modelo.getColumnCount(); j++) {
                    st = (String) modelo.getValueAt(i, j);
                    verificar = 0;
                    if (campos.size() == 0) {
                        auxiliar = new Campos();
                        auxiliar.setNombre(st);
                        campos.add(auxiliar);
                        /**
                        * ****************************************
                        * registrooo = registrooo + campos.toString() + "*";
                        * limtadores = limtadores + campos.toString() + "*";
                        * PrintWriter save = new PrintWriter(guarda + ".txt");
                        * save.println(registrooo); save.println(limtadores);
                        *
                        * String archi12 = "" + guarda; String archi2 = ""; for
                        * (int k = 0; k < archi12.length(); k++) { archi2 =
                            * archi2 + archi12.charAt(k); }
                        * System.out.println(archi2);
                        *
                        * modelo1.addElement(campos); save.close();
                        */
                    } else {
                        for (int k = 0; k < campos.size(); k++) {
                            if (campos.get(k).getNombre().equals(st)) {
                                verificar = 1;
                            }
                        }//fin for
                        if (verificar == 0) {
                            auxiliar = new Campos();
                            auxiliar.setNombre(st);
                            campos.add(auxiliar);
                            //******************************************
                            modelo1.addElement(campos);
                        }
                    } // fin else
                }// fin for2
            }// fin for1
            //jComboBox2.setModel(modelo1);
            JOptionPane.showMessageDialog(null, "Se agregó :)");
            for (int i = 0; i < campos.size(); i++) {
                System.out.println(campos.get(i).getNombre());
            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error al guardar campo " + e.getMessage());
        }
    }//GEN-LAST:event_jB_guardarCampoMouseClicked

    private void jB_eliminarCampoMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jB_eliminarCampoMouseClicked
        // BOTON ELIMINAR CAMPO
        try {
            int selectRow = jT_campos.getSelectedRow();
            jT_campos.remove(selectRow);

            if (!campos.isEmpty()) {
                campos.remove(selectRow);
            }
            JOptionPane.showMessageDialog(null, "Se eliminó :)");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error al eliminar " + e.getMessage());
        }
    }//GEN-LAST:event_jB_eliminarCampoMouseClicked

    private void jB_agregarCampoMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jB_agregarCampoMouseClicked
        // BOTON AGREGAR CAMPOS
        String[] columna = new String[1];
        DefaultTableModel model = (DefaultTableModel) jT_campos.getModel();
        if (jT_campos.getColumnCount() == 0) {
            columna[0] = "NOMBRE CAMPOS";
            jT_campos.setModel(new javax.swing.table.DefaultTableModel(new Object[][]{}, columna));
            model.addColumn(columna);
        }
        DefaultTableModel modelo = (DefaultTableModel) jT_campos.getModel();
        Object[] row = {};
        modelo.addRow(row);
        jT_campos.setModel(modelo);
    }//GEN-LAST:event_jB_agregarCampoMouseClicked

    private void jButton4MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton4MouseClicked
        // GUARDAR INDICES
        if (registros.size() != 0) {
            indicesAux.clear();
            for (int i = 0; i < registros.size(); i++) {
                indicesAux.add(i);
            }
        }
        if (indicesAux.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Cargue para generar árbol");
        } else {
            crearArbol(indicesAux);

            try {
                File archivo = new File("C:\\Users\\usuario\\Desktop\\" + metadata + " - TREE.txt");
                FileWriter escribe = new FileWriter(archivo, true);
                String acumula = "";
                for (int i = 0; i < indicesAux.size(); i++) {
                    acumula += indicesAux.get(i) + "\n";
                }
                escribe.write(acumula);
                escribe.close();
            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, "Error al escribir " + e.getMessage());
            }

        }
    }//GEN-LAST:event_jButton4MouseClicked

    private void jButton6MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton6MouseClicked
        // IMPRIMIR ARBOL
        if (registros.size() != 0) {
            indicesAux.clear();
            for (int i = 0; i < registros.size(); i++) {
                indicesAux.add(i);
            }// fin for
        }//fin if

        if (indicesAux.isEmpty()) {
            JOptionPane.showMessageDialog(null, "Verifique si hay indices cargados");
        } else {
            crearArbol(indicesAux);
        }
    }//GEN-LAST:event_jButton6MouseClicked

    private void jt_modficaRegistroFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jt_modficaRegistroFocusGained
        jt_modficaRegistro.selectAll();
    }//GEN-LAST:event_jt_modficaRegistroFocusGained

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(GUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(GUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(GUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(GUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new GUI().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JMenuItem Eliminar_Campo;
    private javax.swing.JPopupMenu Menu_elimina_campo;
    private javax.swing.JPopupMenu Menu_elimina_registros;
    private javax.swing.JMenuItem eliminar_registro;
    private javax.swing.JButton jB_agregarCampo;
    private javax.swing.JButton jB_agregarRegistro;
    private javax.swing.JButton jB_campos;
    private javax.swing.JButton jB_cargarCampos;
    private javax.swing.JButton jB_eliminarCampo;
    private javax.swing.JButton jB_eliminarRegistro;
    private javax.swing.JButton jB_estandariza;
    private javax.swing.JButton jB_generar10mil;
    private javax.swing.JButton jB_guardarCampo;
    private javax.swing.JButton jB_modificarCampo;
    private javax.swing.JButton jB_registro;
    private javax.swing.JButton jB_registroo;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JButton jButton6;
    private javax.swing.JComboBox<String> jCB_cargarCampos;
    private javax.swing.JComboBox<String> jCb_archivo1;
    private javax.swing.JComboBox<proedd2.Campos> jCb_archivo2;
    private javax.swing.JComboBox<String> jComboBox1;
    private javax.swing.JDialog jD_campos;
    private javax.swing.JDialog jD_cruzarArchivos;
    private javax.swing.JDialog jD_estandariza;
    private javax.swing.JDialog jD_indices;
    private javax.swing.JDialog jD_mainNuevo;
    private javax.swing.JDialog jD_registros;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JMenuItem jMenuItem1;
    private javax.swing.JMenuItem jMenuItem2;
    private javax.swing.JMenuItem jMenuItem3;
    private javax.swing.JMenuItem jMenuItem4;
    private javax.swing.JMenuItem jMenuItem5;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTable jT_campos;
    private javax.swing.JTextField jT_newCampo;
    private javax.swing.JTable jT_registros;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JTabbedPane jTabbedPane2;
    private javax.swing.JButton jb_ModificaRegistro;
    private javax.swing.JButton jb_buscarRegistro;
    private javax.swing.JButton jb_cruzaArchivoo;
    private javax.swing.JButton jb_cruzar;
    private javax.swing.JButton jb_excel;
    private javax.swing.JButton jb_guardarIndices;
    private javax.swing.JButton jb_imprimirTree;
    private javax.swing.JButton jb_seleccionaArchi;
    private javax.swing.JButton jb_xml;
    private javax.swing.JTextField jt_modficaRegistro;
    // End of variables declaration//GEN-END:variables

    String metadata = "";
    String registrooo = "";
    String limtadores = "";
    Archivos archivo = new Archivos();
    File archivoo_global;
    int indexGlobal;
    Boolean cargado = false;
    Raiz arbolB = new Raiz(6);

    DefaultComboBoxModel model2_archi = new DefaultComboBoxModel();
    ArrayList<Campos> campo10mil = new ArrayList();
    ArrayList<Registros> registro10mil = new ArrayList();

    ArrayList<Campos> campos = new ArrayList();
    ArrayList<Registros> registros = new ArrayList();
    ArrayList<Integer> indicesAux = new ArrayList();

    ArrayList<Campos> camposCruza1 = new ArrayList();//l 2 archivo al cruzar
    ArrayList<Campos> camposCruza2 = new ArrayList();

    ArrayList<Registros> registros2 = new ArrayList();//Cruzar
    ArrayList<Registros> registros3 = new ArrayList();//Cruzar

    public ArrayList<Campos> nuevoCampoo(ArrayList<Campos> campos) {
        ArrayList<Campos> temp = new ArrayList();
        for (int i = 0; i < campos.size(); i++) {
            Campos camp = new Campos();
            camp.setNombre(campos.get(i).getNombre());
            temp.add(camp);
        }
        return temp;
    }// fin newCampo

    public ArrayList<Campos> llenarCampos() {
        ArrayList<Campos> temp = new ArrayList();
        for (int i = 0; i < campos.size(); i++) {
            Campos c = new Campos();
            c.setNombre(campos.get(i).getNombre());
            temp.add(c);
        }//fin for
        return temp;
    } // fin llenarCampos
    
    public String leer(String p) {
        String acumula = "";
        try {
            FileReader fr = new FileReader(p);
            BufferedReader br = new BufferedReader(fr);
            String linea = "";

            while (linea != null) {
                linea = br.readLine();
                acumula += linea;
            }
            fr.close();
        } catch (IOException e) {
            System.out.println("No se encontra el archivo");
        }
        return acumula;
    }// fin leer

    public void crearArbol(ArrayList<Integer> a) {
        arbolB = new Raiz(6);
        for (int i = 0; i < a.size(); i++) {
            arbolB.insert(i);
        }
        for (int i = 0; i < indicesAux.size(); i++) {
            System.out.println(indicesAux.get(i));
        }
    }// fin crearArbol

}
