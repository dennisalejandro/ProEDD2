package proedd2;

import java.util.ArrayList;

public class Archivos {

    ArrayList<Registros> registros = new ArrayList();
    String nom;

    public Archivos() {
    }

    public ArrayList<Registros> getRegistros() {
        return registros;
    }

    public void setRegistros(ArrayList<Registros> regis) {
        this.registros = regis;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public Registros getRegistro(int n) {
        return registros.get(n);
    }

    public void setRegistros(Registros reg) {
        registros.add(reg);
    }
}
