package proedd2;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import org.jdom.Document;
import org.jdom.Element;
import org.jdom.output.XMLOutputter;

public class ExportarXML {

    Registros registro = new Registros();
    ArrayList<Registros> regis = new ArrayList();
    public ArrayList<String> llavee = new ArrayList();
    public ArrayList<String> valor = new ArrayList();
    public String nomArchi;
    
    public ExportarXML() {
    }

    public Registros getRegistro() {
        return registro;
    }

    public void setRegistro(Registros registro) {
        this.registro = registro;
    }

    public ArrayList<Registros> getRegis() {
        return regis;
    }

    public void setRegis(ArrayList<Registros> regis) {
        this.regis = regis;
    }

    public ArrayList<String> getLlavee() {
        return llavee;
    }

    public void setLlavee(ArrayList<String> llavee) {
        this.llavee = llavee;
    }

    public ArrayList<String> getValor() {
        return valor;
    }

    public void setValor(ArrayList<String> valor) {
        this.valor = valor;
    }

    public String getNomArchi() {
        return nomArchi;
    }

    public void setNomArchi(String nomArchi) {
        this.nomArchi = nomArchi;
    }

    public void saveXML() {
        Element root = new Element("Personas");
        Document documentt = new Document(root);

        for (int a = 0; a < regis.size(); a++) {
            Element num = new Element("Registro");
            String aux = "" + a;
            num.setAttribute("N.", aux);
            for (int b = 0; b < regis.get(a).getCampo().size(); b++) {
                llavee.add(regis.get(a).getCampo().get(b).getNombre());
                valor.add(regis.get(a).getCampo().get(b).getContenido());

            }// fin for

            for (int c = 0; c < llavee.size(); c++) {
                Element campo = new Element(llavee.get(c));
                campo.setText(valor.get(c));
                num.addContent(campo);
            }// fin for

            root.addContent(num);
            llavee.clear();
            valor.clear();
        }// fin for principal

        XMLOutputter xmlOut = new XMLOutputter();

        try {
            //paraarchivo de salida
            FileWriter archive = new FileWriter(new File("C:\\Users\\usuario\\Desktop\\" + nomArchi + ".xml"));
            //Imprimiendo XML
            xmlOut.output(documentt, archive);
        } catch (IOException e) {
            e.printStackTrace();
        }

    }//fin saveXML

}
