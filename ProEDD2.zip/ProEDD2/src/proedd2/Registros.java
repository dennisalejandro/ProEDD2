package proedd2;

import java.util.ArrayList;

public class Registros {

    ArrayList<Campos> campo = new ArrayList();
    String nombree;
    int index;

    public Registros() {

    }

    public Registros(String nomb) {
        this.nombree = nomb;
    }

    public ArrayList<Campos> getCampo() {
        return campo;
    }

    public void setCampo(ArrayList<Campos> campo) {
        this.campo = campo;
    }
    
    public String getNombree() {
        return nombree;
    }

    public void setNombree(String nombree) {
        this.nombree = nombree;
    }

    public Campos getCampo(int n) {
        return campo.get(n);
    }

    public void setCampo(Campos c) {
        campo.add(c);
    }

    public int getIndex() {
        return index;
    }

    public void setIndex(int index) {
        this.index = index;
    }

    @Override
    public String toString() {
        return campo.get(0).getContenido();
    }
    
    public String toString2() {
        return nombree;
    }


    public int getTamano() {
        return campo.size() * 2;
    }
}
